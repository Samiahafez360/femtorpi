#ifndef ControllerNetworkUtilities_h
#define ControllerNetworkUtilities_h

#include <istream>
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sstream>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>

#include <string>

#include <sstream>

#include <iostream>

#include <arpa/inet.h>
#include <iostream>
#include <cstdint>
#include <vector>
#include "Helper.h"
#include "Block.h"
#include <string.h>
#include <stdio.h>

using namespace std;

struct response{
		int rangeStart;
		long out;
	};


class ControllerNetworkUtilities {


public:
   ControllerNetworkUtilities(int initial){
      nofhelpers = initial;
    }
	ControllerNetworkUtilities(){
      nofhelpers = 0;
	  printf("Controller Message : NetUtil Constructor\r\n");
    }

    int getnofAvailableHelpers(){
      return nofhelpers;
    }
    vector<char*> getAvailableHelpers(){
      return IPs;
    }

	void send_message_to_helper(int id, const char* message, int size ){

		auto timebeforeminingrangesent = std::chrono::system_clock::now();
		std::time_t start_time_range = std::chrono::system_clock::to_time_t(timebeforeminingrangesent);
		std::cout << "\n ALERT !!! :Time time before mining range sent " << std::ctime(&start_time_range);

		printf("Controller Message : Send message to helper\r\n");
		if( send(socket_nums[id], message, size, 0) != size )
            {
                perror("send");
            }

	}
	void receive_from_helper(int sizeofbuffer, char* buffer, int socket){

		printf( "Home message: in receive function body  message from the helper of size %d and equals %s", sizeofbuffer,buffer);


		char* tokens;
		int  _sNonce = 0, out= 0;

		tokens = strtok(buffer, "$");
		if (tokens!= NULL ) _sNonce = stoi(tokens);
		printf("starting nonce at:%d\n",_sNonce );

		tokens = strtok(NULL,"$");
		if (tokens!= NULL ) out = stoi(tokens) ;
		printf("nonce found at :%d\n",_sNonce );


			printf( "Home message: received message from the helper %s",buffer);
			if (out > 0){
				//block is found
				cout<< "Block found";
			}
			response s;
			s.rangeStart = _sNonce;
			s.out = (long)out;
			responses.push_back(s);


	}



    void updateHelpers(bool addorremove, int socket_num, char* ip, int port){


      if(addorremove){
		  printf("Controller Message : Adding helper \r\n");
			socket_nums.emplace_back(socket_num);
			IPs.emplace_back(ip);
			ports.emplace_back(port);
			nofhelpers++;
			printf("Controller Message : number of helpers now %d\r\n",nofhelpers);
	  }else{
		   printf("Controller Message : removing helper \r\n");

			int pos;
			for (int j=0; j<socket_nums.size(); j++){ if (socket_nums[j] == socket_num) pos = j;}
			socket_nums.erase(socket_nums.begin()+ pos);
			IPs.erase(IPs.begin() + pos);
			ports.erase(ports.begin()+ pos);
			nofhelpers--;

	  }
    }
	void con_connect ();

	std::vector<int> socket_nums;
	std::vector<char*> IPs;
	std::vector<int> ports;
	std::vector<response> responses;



  private:
    int nofhelpers;

};
 #endif
