#include "Controller.h"
#include "ControllerNetworkUtilities.hpp"
#include <cmath>
#include <thread>
#include <istream>
#include <iostream>
#include <chrono>



using namespace std;
#define DIFFICULTY 3

Controller::Controller(){

// cosult the network about the chain to get the last hash and try to min over it
  populatechain();
  printf("Controller Message : Constructor\r\n");
  netutils = new ControllerNetworkUtilities();
}
Controller::Controller(int initial){
// cosult the network about the chain to get the last hash and try to min over it
  populatechain();
  netutils = new ControllerNetworkUtilities(initial);
}
// before networking
void Controller::AddBlock(){
	_vChain.push_back(*currentblock);
	std::cout<<"adding the block";
}

int Controller::getnofhelpers(){

	//networking: return netutils->getnofAvailableHelpers();
	return netutils->getnofAvailableHelpers();
}

void Controller::startMining(){
	printf("Controller Message : Starting to mine \r\n");

	starttime = std::chrono::system_clock::now();
    std::time_t start_time = std::chrono::system_clock::to_time_t(starttime);


    //Prepare the attributes.
	currentblock = new Block(_vChain.size(), "next block is being mined");

	int n = netutils->getnofAvailableHelpers();
	long range = powl(2,DIFFICULTY+10);
	long indrange = ceil (range*1.0 /n*1.0);

	// start threading and sending to helpers
	std::cout << "started mining at " << std::ctime(&start_time);
	for (unsigned i =0 ; i < n ; i++){
		printf("Controller Message : Preparing thread \r\n");
		helperths.push_back(std::thread(&Controller::sendrangetohelper,this,i,indrange));
		helperths[i].join();
	}

	for (unsigned i =0 ; i < n ; i++){
		helperths.erase(helperths.begin()+i);
	}



}

void Controller::sendrangetohelper(unsigned id, uint32_t indrange ){

	printf("Controller Message : Preparing mining range for %d \r\n", id);

	std::cout<<"\n thread "<< id <<"is starting" << indrange;
	long long int t = static_cast<long long int> (std::chrono::system_clock::to_time_t(starttime));

	// hash already calulated problem cleared all threads reading
	string s = currentblock->allblock;

	// all local vars no thread problem
	stringstream message;
	message<< id<<"$"<<indrange<<"$"<<DIFFICULTY<<"$"<<s<<"$"<<t;

	char inchararr [message.str().size()+1];
	message.str().copy(inchararr, message.str().size()+1);
	inchararr[message.str().size()] ='\0';

	printf("Controller Message : Message  %s \r\n", message.str());

	//responses[id] = helpers[id].minenozk(id*indrange, indrange, DIFFICULTY, *currentblock,starttime);
	netutils->send_message_to_helper(id, inchararr,message.str().size());

	printf("Controller Message : Message sent  %s to helper %d \r\n", message.str(),id );
}




Block Controller::_GetLastBlock() const{

}

void Controller::populatechain(){
  //scan the network for the blockchain

  //now we will start with an empty blockchain
  _vChain.emplace_back(0, "Genesis");
}

  void Controller::updateHelpers(){
    // scan the network for helpers and which ones are available

    //Now we only add the previously known number.
	helpers.emplace_back();
	responses.push_back(-1);

  }
