#ifndef HELPER_H
#define HELPER_H

#include <cstdint>
#include <vector>
#include <iostream>

#include <iterator>
#include <map>
#include <istream>
#include "Block.h"
#include <string>
#include <chrono>

class Helper {

public:

	Helper();
	Helper(int sizofgad);

	int minenozk(uint32_t _sNonce, uint32_t range,uint32_t nDifficulty,Block mBlock,std::chrono::system_clock::time_point starttime);
	int minenozk_net(uint32_t _sNonce, uint32_t range,uint32_t nDifficulty,char* mBlock,long long starttime);



    char* getIP();

private:
	// for either gadgets


	//bulk shas


	string _CalculateHash(uint32_t _nIndex, uint32_t _nNonce,string sPrevHash,time_t _tTime,string _sData) const;
	string _CalculateHash( char* mBlock, uint32_t _nNonce) const;
    char* IP;


};

#endif
